import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Button } from 'react-native';
import LoginScreen from '../screens/Login_Screen';
import RegisterScreen from '../screens/Reg_Screen';
import DashboardScreen from '../screens/DashboardScreen';
import AlertGuidelineScreen from '../screens/AlertGuidelineScreen';
import OfflineScreen from '../screens/OfflineScreen';
import { useNavigation } from '@react-navigation/native';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const logout = (navigation) => {
  // navigation.reset({
  //   index: 0,
  //   routes: [{ name: 'Login' }],
  // });
  navigation.navigate('Login');
}

const AuthNavigator = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
};

const AppNavigator = () => {
  const navigation = useNavigation();
  return (
    <>
    <Tab.Navigator>
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="AlertGuideline" component={AlertGuidelineScreen} />
      <Tab.Screen name="Offline" component={OfflineScreen} />
      {/* <Tab.Screen name="Login" component={LoginScreen} /> */}
      {/* <Tab.Screen name="Register" component={RegisterScreen} /> */}
    </Tab.Navigator>
    <Button title='Logout' onPress={() => navigation.navigate('Login')}></Button>
    </>
  );
};

export default AppNavigator;