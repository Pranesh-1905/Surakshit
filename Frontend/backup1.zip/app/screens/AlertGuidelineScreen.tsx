// src/screens/AlertGuideline/AlertGuidelineScreen.tsx

import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

const AlertGuidelineScreen: React.FC = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Alert!</Text>
      <Text style={styles.alertMessage}>Severe flood warning in your area.</Text>
      
      <Text style={styles.title}>Guidelines</Text>
      <Text style={styles.guideline}>
        1. Move to higher ground immediately.
      </Text>
      <Text style={styles.guideline}>
        2. Avoid walking or driving through floodwaters.
      </Text>
      <Text style={styles.guideline}>
        3. Stay informed through local news and weather reports.
      </Text>
      <Text style={styles.guideline}>
        4. Keep emergency supplies like food, water, and medications ready.
      </Text>
      <Text style={styles.guideline}>
        5. Follow instructions from local authorities and emergency services.
      </Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  alertMessage: {
    fontSize: 18,
    color: 'red',
    marginBottom: 16,
  },
  guideline: {
    fontSize: 16,
    marginBottom: 8,
  },
});

export default AlertGuidelineScreen;
