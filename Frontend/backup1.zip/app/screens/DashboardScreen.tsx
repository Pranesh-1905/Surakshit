// src/screens/Dashboard/DashboardScreen.tsx

import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';

const DashboardScreen: React.FC = () => {
  const [weatherData, setWeatherData] = useState({
    temperature: '',
    windSpeed: '',
    humidity: '',
    rainfall: '',
  });

  useEffect(() => {
    // Fetch weather data from your API or service
    // setWeatherData({ temperature: '30°C', windSpeed: '15 km/h', humidity: '60%', rainfall: '20%' });
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Current Weather</Text>
      <Text style={styles.info}>Temperature: {weatherData.temperature}</Text>
      <Text style={styles.info}>Wind Speed: {weatherData.windSpeed}</Text>
      <Text style={styles.info}>Humidity: {weatherData.humidity}</Text>
      <Text style={styles.info}>Rainfall: {weatherData.rainfall}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 16,
  },
  info: {
    fontSize: 18,
    marginVertical: 4,
  },
});

export default DashboardScreen;
